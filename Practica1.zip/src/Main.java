public class Main
{
    public static void main(String[] args)
    {
        int p1 = 10;
        int p2 = 20;
        int p3 = 30;
        suma (p1, p2, p3);
    }
    public static void suma(int a, int b, int c)
    {
        System.out.println(a + b + c);
    }
}
